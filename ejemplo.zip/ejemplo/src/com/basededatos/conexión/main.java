
package com.basededatos.conexión;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		conexionbd obj = new conexionbd();
		obj.getDatos();
		

	}

}
