package com.basededatos.conexión;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class conexionbd {
	private Connection con;
	private Statement st;
	private ResultSet rs;
	
	public conexionbd() {
		try {
			Class.forName("com.mysql.jdbc.Driver"); // forName es el método para conectarnos
			con = DriverManager.getConnection("jdbc:mysql://localhost:3307/ejemplo", "root", null); // Con almacenará la conexión a la DB, Get.. es el método
			st = con.createStatement(); // acá utilizamos la variable st + el método createstatement
			
			//String query = "INSERT INTO usuarios (nombre, cedula, email) VALUES ('sofia', 1000987234 , 'sofialq1@gmail.com')";
			//st.executeUpdate(query);
			//System.out.println("Se agrego un nuevo usuario, realiza la consulta para verificar el ingreso");
			
		//	String query = "UPDATE usuarios SET nombre = 'lore' WHERE id = 3";
		//	st.executeUpdate(query);
		//	System.out.println("Se actualizó un usuario, realiza la consulta para verificar la actualización");

		//	String query = "DELETE FROM usuarios WHERE nombre = 'felipe'";
		//	st.executeUpdate(query);
		//	System.out.println("Se eliminó un usuario, realiza la consulta para verificar la eliminación");
			
			
				
			
		}catch(Exception exc) {
			exc.printStackTrace();
			
		}
				
}
	//Consultas a la base de datos
	
	
			public void getDatos(){
				try {
					String query ="SELECT id, nombre, cedula, email FROM usuarios";
					rs = st.executeQuery(query);	
					
					while(rs.next()) {
						String id = rs.getString("id");			
					String nombre = rs.getString("nombre");
					String cedula = rs.getString("cedula");
					String email = rs.getString("email");
					System.out.println("Id: "+ id +"\nnombre: " + nombre + "\ncedula: " + cedula + "\nemail: " + email );
					}
					
				} catch(Exception exc) {
					exc.printStackTrace();
				}finally {
					try {
						con.close();
					}catch(Exception exc) {
						exc.printStackTrace();
					}
				}
			}
}
